package com.example.backendapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
